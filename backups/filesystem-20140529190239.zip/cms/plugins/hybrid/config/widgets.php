<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	__('Datasource') => array(
		'hybrid_document' => __('Hybrid document'),
		'hybrid_headline' => __('Hybrid Headline'),
		'hybrid_tags' => __('Hybrid tags'),
	)
);