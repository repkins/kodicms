DROP TABLE `__TABLE_PREFIX__messages`;
DROP TABLE `__TABLE_PREFIX__messages_users`;