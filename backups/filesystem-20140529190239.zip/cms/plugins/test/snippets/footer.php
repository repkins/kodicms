<hr />
<p class="muted pull-left">&copy; 2012<?php echo (date('Y') > 2012) ? ' - ' . date('Y') : ''; ?> <?php echo HTML::anchor( 'https://github.com/butschster/kodicms', CMS_NAME ) ?> v<?php echo CMS_VERSION; ?></p>

<p class="pull-right">Powered by <?php echo HTML::anchor( 'http://kohanaframework.org/', 'Kohana' ) ?> v<?php echo Kohana::VERSION ?></p>