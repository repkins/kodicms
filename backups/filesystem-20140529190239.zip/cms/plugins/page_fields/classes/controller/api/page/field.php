<?php defined( 'SYSPATH' ) or die( 'No direct script access.' );

class Controller_API_Page_Field extends KodiCMS_Controller_API_Page_Field {}