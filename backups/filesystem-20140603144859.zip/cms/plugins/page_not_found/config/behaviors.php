<?php defined('SYSPATH') or die('No direct access allowed.');

return array(

	'page_not_found' => array(),
);