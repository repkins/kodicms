<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	'Comments' => 'Комментарии',
	'Comments counter' => 'Счетчик комментариев',
);