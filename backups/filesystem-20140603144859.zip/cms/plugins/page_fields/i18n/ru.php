<?php defined( 'SYSPATH' ) or die( 'No direct access allowed.' );

return array(
	'Page fields' => 'Дополнительные поля',
	'Copy fields from' => 'Скопировать поля у страницы',
	"Don't copy" => 'Не копировать',
	'Field title' => 'Название',
	'Field key' => 'Ключ',
	'Field value' => 'Значение',
);