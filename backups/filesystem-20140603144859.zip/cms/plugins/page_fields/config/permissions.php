<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	'page' => array(
		array(
			'action' => 'custom_fields',
			'description' => 'Manage custom fields'
		),
	)
);