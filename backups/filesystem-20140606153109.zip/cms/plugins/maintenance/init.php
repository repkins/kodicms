<?php defined('SYSPATH') or die('No direct access allowed.');

Plugin::factory('maintenance', array(
	'title' => 'Maintenance mode',
))->register();
