<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	'Enable compiler' => 'Включить компилятор',
	'Paths' => 'Пути',
	'Less folder path' => 'Путь до папки с less',
	'Css folder path' => 'Путь до папки с css',
	'Directory :dir not exists' => 'Директория :dir не существует'
);