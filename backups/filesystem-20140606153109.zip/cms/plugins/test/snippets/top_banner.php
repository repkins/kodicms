<div class="hero-unit">
	<h1><?php echo Config::get('site', 'title'); ?></h1>
	<ul>
		<li>Login: demo</li>
		<li>Password: demodemo</li>
	</ul>
	<hr />
	<p class="text-center">
		<?php echo HTML::anchor(ADMIN_DIR_NAME, __('Backend'), array('class' => 'btn btn-large')); ?> <?php echo HTML::anchor('http://kodicms.ru/forum.html', 'Форум', array('class' => 'btn btn-large btn-primary')); ?>
	</p>
</div>
<div style="margin: 60px;">
	<h3>Demo login:</h3>
	<ul>
		<li>Предоставление инструментов для создания содержимого, организация совместной работы над содержимым,</li>
		<li>Управление содержимым: хранение, контроль версий, соблюдение режима доступа, управление потоком документов и т. п.,</li>
		<li>Публикация содержимого,</li>
		<li>Представление информации в виде, удобном для навигации, поиска.</li>
	</ul>
</div>