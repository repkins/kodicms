<?php defined( 'SYSPATH' ) or die( 'No direct access allowed.' );

return array(
	'DataSource_Hybrid_Field_Factory::field_not_exists'	=> 'Field with the same key :value exists.',
);
