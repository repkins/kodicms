<?php defined( 'SYSPATH' ) or die( 'No direct script access.' );

Plugin::factory('googleanalytics', array(
	'title' => 'Google Analytics',
	'description' => 'Google Analytics lets you measure your advertising ROI as well as track your Flash, video, and social networking sites and applications.',
	'version' => '1.0.0',
))->register();