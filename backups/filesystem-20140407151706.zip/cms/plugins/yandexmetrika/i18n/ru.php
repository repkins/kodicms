<?php defined( 'SYSPATH' ) or die( 'No direct access allowed.' );

return array(
	'Yandex metrika settings' => 'Настройки метрики',
	'Metrics ID' => 'ID метрики',
	'WebVisor' => 'Вебвизор',
	'Click map' => 'Карта кликов',
	'External links, file downloads and "Share" button report' => 'Внешние ссылки, загрузки файлов и отчёт по кнопке «Поделиться»',
	'Accurate bounce rate' => 'Точный показатель отказов',
	'' => '',
	'' => '',
	
);