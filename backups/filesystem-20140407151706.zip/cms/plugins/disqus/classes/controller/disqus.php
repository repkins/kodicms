<?php defined('SYSPATH') or die('No direct access allowed.');

/**
 * @package		KodiCMS/Disqus
 * @category	Controller
 * @author		ButscHSter
 */
class Controller_Disqus extends Controller_System_Plugin {}