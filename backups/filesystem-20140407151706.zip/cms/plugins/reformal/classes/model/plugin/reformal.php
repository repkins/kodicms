<?php defined( 'SYSPATH' ) or die( 'No direct script access.' );

class Plugins_Reformal extends Plugins_Item {

	public function footer_view()
	{
		
	}
}