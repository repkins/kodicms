<?php defined( 'SYSPATH' ) or die( 'No direct access allowed.' );

return array(
	'Domain' => 'Основной домен',
	'Check url suffix (<strong>:url_suffix</strong>)' =>
		'Проверять наличие окончания URL (<strong>:url_suffix</strong>)'
);