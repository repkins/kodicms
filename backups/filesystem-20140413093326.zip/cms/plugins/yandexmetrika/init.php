<?php defined( 'SYSPATH' ) or die( 'No direct script access.' );

Plugin::factory('yandexmetrika', array(
	'title' => 'Yandex Метрика',
	'description' => 'Метрика посещения пользователями сайта',
))->register();