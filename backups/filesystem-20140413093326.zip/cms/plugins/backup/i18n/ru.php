<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	'Backup' => 'Резервное копирование',
	'Create database backup' => 'Сделать бэкап БД',
	'Create filesystem backup' => 'Сделать бэкап файлов',
	'Created' => 'Создан',
	'File name' => 'Название файла',
	'File size' => 'Размер',
	'Upload backup file' => 'Загрузить бэкап на сервер',
	'Upload' => 'Загрузить',
	'Backup view :file' => 'Просмот дампа БД  (:file)',
	'Folder (:folder) not exist!' => 'Папка (:folder) не существует',
	'Folder (:folder) mus be writable!' => 'Папка (:folder) должна быть доступна для записи',
	'File is not attached!' => 'Файл не прекреплен',
	'Bad format of file!' => 'Не верный формат файла',
	'File :filename uploaded succefully' => 'Файл :filename успешно загружен на сервер',
		
	/* Validation */
	'Must be a directory' => 'Должен быть каталог',
);