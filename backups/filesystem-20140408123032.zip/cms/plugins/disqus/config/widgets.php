<?php defined('SYSPATH') or die('No direct access allowed.');

return array(
	__('Disqus') => array(
		'disqus_comments' => __('Comments'),
		'disqus_counter' => __('Comments counter'),
	),
);