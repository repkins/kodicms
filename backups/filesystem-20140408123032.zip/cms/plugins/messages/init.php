<?php defined('SYSPATH') or die('No direct access allowed.');

Plugin::factory('messages', array(
	'title' => 'User messages',
	'description' => 'Provides user messages system.',
))->register();