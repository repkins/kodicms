<?php defined('SYSPATH') or die('No direct access allowed.');

class Controller_YandexMetrika extends Controller_System_Plugin {}