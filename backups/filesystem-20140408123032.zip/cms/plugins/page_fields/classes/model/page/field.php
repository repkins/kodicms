<?php defined('SYSPATH') or die('No direct access allowed.');

class Model_Page_Field extends KodiCMS_Model_Page_Field {}