<?php defined( 'SYSPATH' ) or die( 'No direct access allowed.' );

return array(
	'Current text' => 'Текущий текст',
	'Clear diff' => 'Убрать различия',
	'Show diff' => 'Показать различия',
	'Use this revision' => 'Вернуть этот вариант'
);