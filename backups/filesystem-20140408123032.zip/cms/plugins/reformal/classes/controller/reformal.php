<?php defined('SYSPATH') or die('No direct access allowed.');

class Controller_Reformal extends Controller_System_Plugin {}