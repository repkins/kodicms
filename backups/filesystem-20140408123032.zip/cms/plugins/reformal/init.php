<?php defined( 'SYSPATH' ) or die( 'No direct script access.' );

Plugin::factory('reformal', array(
	'title' => 'Reformal',
	'description' => 'Реформал – это простой и эффективный сервис обратной связи',
))->register();