<?php if( ! empty($header)) : ?>
<h3 class="p1"><?php echo $header; ?></h3>
<?php endif; ?>
<div class="wrapper">
	<?php $i = 1; foreach($pages as $page) : ?>
		<?php if($i % 4 == 1) : ?>
		<div class="grid_4 alpha">
		<?php endif; ?>
		<ul class="list-1">
			<li>
				<?php echo HTML::anchor($page['uri'], $page['title'], array(
						'class'=>$page['is_active'] ? 'active' : ''
					)); 
				?>
			</li>
		</ul>
		
		<?php if($i % 4 == 0) : ?>
		</div>
		<?php endif; ?>	
	<?php $i++; 	endforeach;?>
	
	<a class="link-1 margin-left" href="#">All Services</a>
	
</div>